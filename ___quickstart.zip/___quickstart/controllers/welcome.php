<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->document->set_title('Welcome to Codeigniter');
	}

	
	public function index()
	{	
		$version = (ENVIRONMENT == 'development') ?  'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '';
		$footnote = '<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. Memory usage: {memory_usage}. '.$version.'</p>';
		$this->document->parse_exec_vars(true)
						->add_js('script.js')
						->inject_view('content_view', 'welcome_view')
						->inject('footnote', $footnote);
	}

	public function kitchensink()
	{	
		$this->document->set_title('Kitchensink', true);
		$this->document->inject_static('content','kitchensink');
	}


}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */