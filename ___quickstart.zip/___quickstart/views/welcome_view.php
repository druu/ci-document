	<h1>Welcome to CodeIgniter!</h1>

	<div id="body">
		<p>The page you are looking at is being generated dynamically by CodeIgniter.</p>

		<p>If you would like to edit this page you'll find it located at:</p>
		<code>application/views/welcome_view.php</code>

		<p>The corresponding controller for this page is found at:</p>
		<code>application/controllers/welcome.php</code>

		<p>If you are exploring CodeIgniter for the very first time, you should start by reading the <a href="http://codeigniter.com/user_guide/">User Guide</a>.</p>

		<p>The page is rendered by <b>_druu</b>'s template engine</p>
		<pre><code>
    Files:
        application/config/document.php
        application/libraries/Document.php
        application/hooks/document/Document_renderer.php
        templates/default/*

        Note: Base-, Partial- and Static-Files _MUST_ be prefixed with an underscore _AND_ end with .php
    
    Special/Reserved Markers:
    Marker:              Used for:
      _TPL_HEAD            Meta-Tags and CSS-Files in the &lt;head&gt;-section
      _TPL_TITLE           Compiled page title
      _TPL_MSG             Sytem Messages / Notifications
      _TPL_SCRIPTS         JS files to be loaded // MUST NOT be used in the template files
      _TPL_DEBUG           Micro debug listing
      _TPL_PROFILE         CI's Profiler output
      _TPL_OB_CONTENTS     General output buffer
    
    !!! Make sure to use them in your template !!!

    Public functions:
        $this->document->exists($file, $path_key)                       // checks whether the file exists in the
                                                                        // given path (base, partials, css...);
        $this->document->add_link($array);                              // array('rel'=>'favicon', 'src'=>'favicon.ico');
        $this->document->add_css($file $media);                         // example: $file: '/assets/css/template.css'
                                                                        //          $media: any valid media type
        $this->document->add_js($file, $pos);                           // example: $file: '/assets/js/my_plugin.js'
                                                                        //          $pos: body or head
                                                                        // filenames starting with / will override the path setting
        $this->document->add_meta($name, $content, $attr);              // example: 'author', 'yoMomma!' 
                                                                        //          $attr: 'name', 'http-equiv' or 'property'

     /***********************************************************************************************************
     * VERY EXPERIMENTAL!!!                                                                                     *
     ***********************************************************************************************************/

        So there is this function: $this->document->add($args, $special);

        This is supposed to be a shorthand function for the add* methods (except for add_link)
        Plus it can handle bulk additions.
        The first param can be an array or a string. 
        The second is supposed to feed the last param of the add-methods and is optional.

        A valid example for an add-array would be:
        $add = array(
                    'jquery.something.css',                     // adds a stylesheet-link to the head
                    'head'=>'script.js',                        // adds a script tag to the head
                    array('head'=>'script2.js'),                // another script to the head
                    'name' => array('author' => '_druu')        // adds &lt;meta name="author" content="_druu" /&gt;
            );

        Go ahead and give it a try. And tell me what happens ;)

     /***********************************************************************************************************
     * END OF VERY EXPERIMENTAL!!!                                                                              *
     ***********************************************************************************************************/


        $this->document->inject($marker, $string);                      // example: 'copyright', 2011
        $this->document->inject_partial($marker, $partial_filename);    // example: 'topmenu', 'topmenu'
        $this->document->inject_static($marker, $static_filename);      // example: 'content', 'kitchensink'

        // this replaces $this->load->view();
        $this->document->inject_view($marker, $view_file);              // example: 'sidebar', 'sidebar'

        // NOTE: The inject methods have a third parameter which, if set to TRUE, appends the injection to existing
        //       injections on that marker.

        // title stuff
        $this->document->set_title($title, $append, $use_separator);    // Param 1: Title string
                                                                        // Param 2: Append to current title? (bool)
                                                                        // Param 3: Append using title separator? (bool)

        $this->document->get_title();                                   // Returns the title (w/o pre- & suffix)

        
        // CI's parse exec vars
        // Will replace any occurance of { memory_usage } and { elapsed_time } in the output buffer
        $this->document->parse_exec_vars(true);

        /**
         * NOTE: The methods add_*(), inject*(), set_title() and parse_exec_vars() are chainable.
         */

        // Remove un-used markers  (will be called automatically)
        $this->document->clean();

        // Compile Metas, Css links, and script thingies  (will be called automatically)
        $this->document->prepare_render();


        // Get Output Buffer
        $this->document->get_contents();


     /***********************************************************************************************************
     * Make sure you checkout the source-files, just in case I've forgotten to mention something here ;)        *
     ***********************************************************************************************************/
		</pre></code>
	</div>

