<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-12-10 00:03:07 --> Config Class Initialized
DEBUG - 2011-12-10 00:03:07 --> Hooks Class Initialized
DEBUG - 2011-12-10 00:03:07 --> Utf8 Class Initialized
DEBUG - 2011-12-10 00:03:07 --> UTF-8 Support Enabled
DEBUG - 2011-12-10 00:03:07 --> URI Class Initialized
DEBUG - 2011-12-10 00:03:07 --> Router Class Initialized
DEBUG - 2011-12-10 00:03:07 --> No URI present. Default controller set.
DEBUG - 2011-12-10 00:03:07 --> Output Class Initialized
DEBUG - 2011-12-10 00:03:07 --> Security Class Initialized
DEBUG - 2011-12-10 00:03:07 --> Input Class Initialized
DEBUG - 2011-12-10 00:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-10 00:03:07 --> Language Class Initialized
DEBUG - 2011-12-10 00:03:07 --> Loader Class Initialized
DEBUG - 2011-12-10 00:03:07 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-10 00:03:07 --> Controller Class Initialized
DEBUG - 2011-12-10 00:03:07 --> File loaded: application/views/welcome_view.php
INFO  - 2011-12-10 00:03:07 --> Replaced Marker: COPYRIGHT
INFO  - 2011-12-10 00:03:07 --> Replaced Marker: CONTENT_VIEW
INFO  - 2011-12-10 00:03:07 --> Replaced Marker: _TPL_TITLE
INFO  - 2011-12-10 00:03:07 --> Replaced Marker: _TPL_HEAD
INFO  - 2011-12-10 00:03:07 --> Replaced Marker: _TPL_SCRIPTS
DEBUG - 2011-12-10 00:03:43 --> Config Class Initialized
DEBUG - 2011-12-10 00:03:43 --> Hooks Class Initialized
DEBUG - 2011-12-10 00:03:43 --> Utf8 Class Initialized
DEBUG - 2011-12-10 00:03:43 --> UTF-8 Support Enabled
DEBUG - 2011-12-10 00:03:43 --> URI Class Initialized
DEBUG - 2011-12-10 00:03:43 --> Router Class Initialized
DEBUG - 2011-12-10 00:03:43 --> No URI present. Default controller set.
DEBUG - 2011-12-10 00:03:43 --> Output Class Initialized
DEBUG - 2011-12-10 00:03:43 --> Security Class Initialized
DEBUG - 2011-12-10 00:03:43 --> Input Class Initialized
DEBUG - 2011-12-10 00:03:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-10 00:03:43 --> Language Class Initialized
DEBUG - 2011-12-10 00:03:43 --> Loader Class Initialized
DEBUG - 2011-12-10 00:03:43 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-10 00:03:43 --> Controller Class Initialized
DEBUG - 2011-12-10 00:03:43 --> File loaded: application/views/welcome_view.php
INFO  - 2011-12-10 00:03:43 --> Replaced Marker: COPYRIGHT
INFO  - 2011-12-10 00:03:43 --> Replaced Marker: CONTENT_VIEW
INFO  - 2011-12-10 00:03:43 --> Replaced Marker: _TPL_TITLE
INFO  - 2011-12-10 00:03:43 --> Replaced Marker: _TPL_HEAD
INFO  - 2011-12-10 00:03:43 --> Replaced Marker: _TPL_SCRIPTS
DEBUG - 2011-12-10 00:03:52 --> Config Class Initialized
DEBUG - 2011-12-10 00:03:52 --> Hooks Class Initialized
DEBUG - 2011-12-10 00:03:52 --> Utf8 Class Initialized
DEBUG - 2011-12-10 00:03:52 --> UTF-8 Support Enabled
DEBUG - 2011-12-10 00:03:52 --> URI Class Initialized
DEBUG - 2011-12-10 00:03:52 --> Router Class Initialized
DEBUG - 2011-12-10 00:03:52 --> Output Class Initialized
DEBUG - 2011-12-10 00:03:52 --> Security Class Initialized
DEBUG - 2011-12-10 00:03:52 --> Input Class Initialized
DEBUG - 2011-12-10 00:03:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-10 00:03:52 --> Language Class Initialized
DEBUG - 2011-12-10 00:03:52 --> Loader Class Initialized
DEBUG - 2011-12-10 00:03:52 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-10 00:03:52 --> Controller Class Initialized
DEBUG - 2011-12-10 00:03:52 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/statics/_kitchensink.php
INFO  - 2011-12-10 00:03:52 --> Replaced Marker: COPYRIGHT
INFO  - 2011-12-10 00:03:52 --> Replaced Marker: CONTENT
INFO  - 2011-12-10 00:03:52 --> Replaced Marker: _TPL_TITLE
INFO  - 2011-12-10 00:03:52 --> Replaced Marker: _TPL_HEAD
INFO  - 2011-12-10 00:03:52 --> Replaced Marker: _TPL_SCRIPTS
DEBUG - 2011-12-10 00:19:38 --> Config Class Initialized
DEBUG - 2011-12-10 00:19:38 --> Hooks Class Initialized
DEBUG - 2011-12-10 00:19:38 --> Utf8 Class Initialized
DEBUG - 2011-12-10 00:19:38 --> UTF-8 Support Enabled
DEBUG - 2011-12-10 00:19:38 --> URI Class Initialized
DEBUG - 2011-12-10 00:19:38 --> Router Class Initialized
DEBUG - 2011-12-10 00:19:38 --> Output Class Initialized
DEBUG - 2011-12-10 00:19:38 --> Security Class Initialized
DEBUG - 2011-12-10 00:19:38 --> Input Class Initialized
DEBUG - 2011-12-10 00:19:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-10 00:19:38 --> Language Class Initialized
DEBUG - 2011-12-10 00:24:26 --> Config Class Initialized
DEBUG - 2011-12-10 00:24:26 --> Hooks Class Initialized
DEBUG - 2011-12-10 00:24:26 --> Utf8 Class Initialized
DEBUG - 2011-12-10 00:24:26 --> UTF-8 Support Enabled
DEBUG - 2011-12-10 00:24:26 --> URI Class Initialized
DEBUG - 2011-12-10 00:24:26 --> Router Class Initialized
DEBUG - 2011-12-10 00:24:26 --> Output Class Initialized
DEBUG - 2011-12-10 00:24:26 --> Security Class Initialized
DEBUG - 2011-12-10 00:24:26 --> Input Class Initialized
DEBUG - 2011-12-10 00:24:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-10 00:24:26 --> Language Class Initialized
DEBUG - 2011-12-10 00:24:26 --> Loader Class Initialized
DEBUG - 2011-12-10 00:24:26 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-10 00:24:26 --> Controller Class Initialized
DEBUG - 2011-12-10 00:24:26 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/statics/_kitchensink.php
INFO  - 2011-12-10 00:24:26 --> Replaced Marker: COPYRIGHT
INFO  - 2011-12-10 00:24:26 --> Replaced Marker: CONTENT
INFO  - 2011-12-10 00:24:26 --> Replaced Marker: _TPL_TITLE
INFO  - 2011-12-10 00:24:26 --> Replaced Marker: _TPL_HEAD
INFO  - 2011-12-10 00:24:26 --> Replaced Marker: _TPL_SCRIPTS
DEBUG - 2011-12-10 00:24:33 --> Config Class Initialized
DEBUG - 2011-12-10 00:24:33 --> Hooks Class Initialized
DEBUG - 2011-12-10 00:24:33 --> Utf8 Class Initialized
DEBUG - 2011-12-10 00:24:33 --> UTF-8 Support Enabled
DEBUG - 2011-12-10 00:24:33 --> URI Class Initialized
DEBUG - 2011-12-10 00:24:33 --> Router Class Initialized
DEBUG - 2011-12-10 00:24:33 --> No URI present. Default controller set.
DEBUG - 2011-12-10 00:24:33 --> Output Class Initialized
DEBUG - 2011-12-10 00:24:33 --> Security Class Initialized
DEBUG - 2011-12-10 00:24:33 --> Input Class Initialized
DEBUG - 2011-12-10 00:24:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-10 00:24:33 --> Language Class Initialized
DEBUG - 2011-12-10 00:24:33 --> Loader Class Initialized
DEBUG - 2011-12-10 00:24:33 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-10 00:24:33 --> Controller Class Initialized
DEBUG - 2011-12-10 00:24:33 --> File loaded: application/views/welcome_view.php
ERROR - 2011-12-10 00:24:33 --> Severity: Warning  --> Missing argument 2 for Document::inject(), called in /Users/_druu/Sites/ci-document/application/controllers/welcome.php on line 17 and defined /Users/_druu/Sites/ci-document/application/libraries/Document.php 308
ERROR - 2011-12-10 00:24:33 --> Severity: Notice  --> Undefined variable: injection /Users/_druu/Sites/ci-document/application/libraries/Document.php 324
INFO  - 2011-12-10 00:24:33 --> Replaced Marker: COPYRIGHT
INFO  - 2011-12-10 00:24:33 --> Replaced Marker: CONTENT_VIEW
INFO  - 2011-12-10 00:24:33 --> Replaced Marker: FOOTNOTE<P CLASS="FOOTER">PAGE RENDERED IN <STRONG>{ELAPSED_TIME}</STRONG> SECONDS. MEMORY USAGE: {MEMORY_USAGE}. CODEIGNITER VERSION <STRONG>2.1.0</STRONG></P>
INFO  - 2011-12-10 00:24:33 --> Replaced Marker: _TPL_TITLE
INFO  - 2011-12-10 00:24:33 --> Replaced Marker: _TPL_HEAD
INFO  - 2011-12-10 00:24:33 --> Replaced Marker: _TPL_SCRIPTS
DEBUG - 2011-12-10 00:24:46 --> Config Class Initialized
DEBUG - 2011-12-10 00:24:46 --> Hooks Class Initialized
DEBUG - 2011-12-10 00:24:46 --> Utf8 Class Initialized
DEBUG - 2011-12-10 00:24:46 --> UTF-8 Support Enabled
DEBUG - 2011-12-10 00:24:46 --> URI Class Initialized
DEBUG - 2011-12-10 00:24:46 --> Router Class Initialized
DEBUG - 2011-12-10 00:24:46 --> No URI present. Default controller set.
DEBUG - 2011-12-10 00:24:46 --> Output Class Initialized
DEBUG - 2011-12-10 00:24:46 --> Security Class Initialized
DEBUG - 2011-12-10 00:24:46 --> Input Class Initialized
DEBUG - 2011-12-10 00:24:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-10 00:24:46 --> Language Class Initialized
DEBUG - 2011-12-10 00:24:46 --> Loader Class Initialized
DEBUG - 2011-12-10 00:24:46 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-10 00:24:46 --> Controller Class Initialized
DEBUG - 2011-12-10 00:24:46 --> File loaded: application/views/welcome_view.php
INFO  - 2011-12-10 00:24:46 --> Replaced Marker: COPYRIGHT
INFO  - 2011-12-10 00:24:46 --> Replaced Marker: CONTENT_VIEW
INFO  - 2011-12-10 00:24:46 --> Replaced Marker: FOOTNOTE
INFO  - 2011-12-10 00:24:46 --> Replaced Marker: _TPL_TITLE
INFO  - 2011-12-10 00:24:46 --> Replaced Marker: _TPL_HEAD
INFO  - 2011-12-10 00:24:46 --> Replaced Marker: _TPL_SCRIPTS
DEBUG - 2011-12-10 01:26:42 --> Config Class Initialized
DEBUG - 2011-12-10 01:26:42 --> Hooks Class Initialized
DEBUG - 2011-12-10 01:26:42 --> Utf8 Class Initialized
DEBUG - 2011-12-10 01:26:42 --> UTF-8 Support Enabled
DEBUG - 2011-12-10 01:26:42 --> URI Class Initialized
DEBUG - 2011-12-10 01:26:42 --> Router Class Initialized
DEBUG - 2011-12-10 01:26:42 --> No URI present. Default controller set.
DEBUG - 2011-12-10 01:26:42 --> Output Class Initialized
DEBUG - 2011-12-10 01:26:42 --> Security Class Initialized
DEBUG - 2011-12-10 01:26:42 --> Input Class Initialized
DEBUG - 2011-12-10 01:26:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-10 01:26:42 --> Language Class Initialized
DEBUG - 2011-12-10 01:26:42 --> Loader Class Initialized
DEBUG - 2011-12-10 01:26:42 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-10 01:26:42 --> Controller Class Initialized
DEBUG - 2011-12-10 01:26:42 --> File loaded: application/views/welcome_view.php
INFO  - 2011-12-10 01:26:42 --> Replaced Marker: COPYRIGHT
INFO  - 2011-12-10 01:26:42 --> Replaced Marker: CONTENT_VIEW
INFO  - 2011-12-10 01:26:42 --> Replaced Marker: FOOTNOTE
INFO  - 2011-12-10 01:26:42 --> Replaced Marker: _TPL_TITLE
INFO  - 2011-12-10 01:26:42 --> Replaced Marker: _TPL_HEAD
INFO  - 2011-12-10 01:26:42 --> Replaced Marker: _TPL_SCRIPTS
