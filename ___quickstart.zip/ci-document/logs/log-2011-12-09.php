<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-12-09 21:32:13 --> Config Class Initialized
DEBUG - 2011-12-09 21:32:13 --> Hooks Class Initialized
DEBUG - 2011-12-09 21:32:13 --> Utf8 Class Initialized
DEBUG - 2011-12-09 21:32:13 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 21:32:13 --> URI Class Initialized
DEBUG - 2011-12-09 21:32:13 --> Router Class Initialized
DEBUG - 2011-12-09 21:32:13 --> No URI present. Default controller set.
DEBUG - 2011-12-09 21:32:13 --> Output Class Initialized
DEBUG - 2011-12-09 21:32:13 --> Security Class Initialized
DEBUG - 2011-12-09 21:32:13 --> Input Class Initialized
DEBUG - 2011-12-09 21:32:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 21:32:13 --> Language Class Initialized
DEBUG - 2011-12-09 21:32:13 --> Loader Class Initialized
DEBUG - 2011-12-09 21:32:13 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 21:32:13 --> Controller Class Initialized
DEBUG - 2011-12-09 21:32:13 --> File loaded: application/views/welcome_view.php
DEBUG - 2011-12-09 21:32:37 --> Config Class Initialized
DEBUG - 2011-12-09 21:32:37 --> Hooks Class Initialized
DEBUG - 2011-12-09 21:32:37 --> Utf8 Class Initialized
DEBUG - 2011-12-09 21:32:37 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 21:32:37 --> URI Class Initialized
DEBUG - 2011-12-09 21:32:37 --> Router Class Initialized
DEBUG - 2011-12-09 21:32:37 --> No URI present. Default controller set.
DEBUG - 2011-12-09 21:32:37 --> Output Class Initialized
DEBUG - 2011-12-09 21:32:37 --> Security Class Initialized
DEBUG - 2011-12-09 21:32:37 --> Input Class Initialized
DEBUG - 2011-12-09 21:32:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 21:32:37 --> Language Class Initialized
DEBUG - 2011-12-09 21:32:37 --> Loader Class Initialized
DEBUG - 2011-12-09 21:32:37 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 21:32:37 --> Controller Class Initialized
DEBUG - 2011-12-09 21:32:37 --> File loaded: application/views/welcome_view.php
DEBUG - 2011-12-09 21:33:41 --> Config Class Initialized
DEBUG - 2011-12-09 21:33:41 --> Hooks Class Initialized
DEBUG - 2011-12-09 21:33:41 --> Utf8 Class Initialized
DEBUG - 2011-12-09 21:33:41 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 21:33:41 --> URI Class Initialized
DEBUG - 2011-12-09 21:33:41 --> Router Class Initialized
DEBUG - 2011-12-09 21:33:41 --> No URI present. Default controller set.
DEBUG - 2011-12-09 21:33:41 --> Output Class Initialized
DEBUG - 2011-12-09 21:33:41 --> Security Class Initialized
DEBUG - 2011-12-09 21:33:41 --> Input Class Initialized
DEBUG - 2011-12-09 21:33:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 21:33:41 --> Language Class Initialized
DEBUG - 2011-12-09 21:33:41 --> Loader Class Initialized
DEBUG - 2011-12-09 21:33:41 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 21:33:41 --> Controller Class Initialized
DEBUG - 2011-12-09 21:33:41 --> File loaded: application/views/welcome_view.php
DEBUG - 2011-12-09 21:34:09 --> Config Class Initialized
DEBUG - 2011-12-09 21:34:09 --> Hooks Class Initialized
DEBUG - 2011-12-09 21:34:09 --> Utf8 Class Initialized
DEBUG - 2011-12-09 21:34:09 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 21:34:09 --> URI Class Initialized
DEBUG - 2011-12-09 21:34:09 --> Router Class Initialized
DEBUG - 2011-12-09 21:34:09 --> No URI present. Default controller set.
DEBUG - 2011-12-09 21:34:09 --> Output Class Initialized
DEBUG - 2011-12-09 21:34:09 --> Security Class Initialized
DEBUG - 2011-12-09 21:34:09 --> Input Class Initialized
DEBUG - 2011-12-09 21:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 21:34:09 --> Language Class Initialized
DEBUG - 2011-12-09 21:34:09 --> Loader Class Initialized
DEBUG - 2011-12-09 21:34:09 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 21:34:09 --> Controller Class Initialized
DEBUG - 2011-12-09 21:34:09 --> File loaded: application/views/welcome_view.php
DEBUG - 2011-12-09 21:34:11 --> Config Class Initialized
DEBUG - 2011-12-09 21:34:11 --> Hooks Class Initialized
DEBUG - 2011-12-09 21:34:11 --> Utf8 Class Initialized
DEBUG - 2011-12-09 21:34:11 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 21:34:11 --> URI Class Initialized
DEBUG - 2011-12-09 21:34:11 --> Router Class Initialized
DEBUG - 2011-12-09 21:34:11 --> No URI present. Default controller set.
DEBUG - 2011-12-09 21:34:11 --> Output Class Initialized
DEBUG - 2011-12-09 21:34:11 --> Security Class Initialized
DEBUG - 2011-12-09 21:34:11 --> Input Class Initialized
DEBUG - 2011-12-09 21:34:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 21:34:11 --> Language Class Initialized
DEBUG - 2011-12-09 21:34:11 --> Loader Class Initialized
DEBUG - 2011-12-09 21:34:11 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 21:34:11 --> Controller Class Initialized
DEBUG - 2011-12-09 21:34:11 --> File loaded: application/views/welcome_view.php
DEBUG - 2011-12-09 21:34:14 --> Config Class Initialized
DEBUG - 2011-12-09 21:34:14 --> Hooks Class Initialized
DEBUG - 2011-12-09 21:34:14 --> Utf8 Class Initialized
DEBUG - 2011-12-09 21:34:14 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 21:34:14 --> URI Class Initialized
DEBUG - 2011-12-09 21:34:14 --> Router Class Initialized
DEBUG - 2011-12-09 21:34:14 --> No URI present. Default controller set.
DEBUG - 2011-12-09 21:34:14 --> Output Class Initialized
DEBUG - 2011-12-09 21:34:14 --> Security Class Initialized
DEBUG - 2011-12-09 21:34:14 --> Input Class Initialized
DEBUG - 2011-12-09 21:34:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 21:34:14 --> Language Class Initialized
DEBUG - 2011-12-09 21:34:14 --> Loader Class Initialized
DEBUG - 2011-12-09 21:34:14 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 21:34:14 --> Controller Class Initialized
DEBUG - 2011-12-09 21:34:14 --> File loaded: application/views/welcome_view.php
DEBUG - 2011-12-09 22:41:03 --> Config Class Initialized
DEBUG - 2011-12-09 22:41:03 --> Hooks Class Initialized
DEBUG - 2011-12-09 22:41:03 --> Utf8 Class Initialized
DEBUG - 2011-12-09 22:41:03 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 22:41:03 --> URI Class Initialized
DEBUG - 2011-12-09 22:41:03 --> Router Class Initialized
DEBUG - 2011-12-09 22:41:03 --> No URI present. Default controller set.
DEBUG - 2011-12-09 22:41:03 --> Output Class Initialized
DEBUG - 2011-12-09 22:41:03 --> Security Class Initialized
DEBUG - 2011-12-09 22:41:03 --> Input Class Initialized
DEBUG - 2011-12-09 22:41:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 22:41:03 --> Language Class Initialized
DEBUG - 2011-12-09 22:41:03 --> Loader Class Initialized
DEBUG - 2011-12-09 22:41:03 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 22:41:03 --> Controller Class Initialized
DEBUG - 2011-12-09 22:41:03 --> File loaded: application/views/welcome_view.php
DEBUG - 2011-12-09 22:42:52 --> Config Class Initialized
DEBUG - 2011-12-09 22:42:52 --> Hooks Class Initialized
DEBUG - 2011-12-09 22:42:52 --> Utf8 Class Initialized
DEBUG - 2011-12-09 22:42:52 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 22:42:52 --> URI Class Initialized
DEBUG - 2011-12-09 22:42:52 --> Router Class Initialized
DEBUG - 2011-12-09 22:42:52 --> No URI present. Default controller set.
DEBUG - 2011-12-09 22:42:52 --> Output Class Initialized
DEBUG - 2011-12-09 22:42:52 --> Security Class Initialized
DEBUG - 2011-12-09 22:42:52 --> Input Class Initialized
DEBUG - 2011-12-09 22:42:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 22:42:52 --> Language Class Initialized
DEBUG - 2011-12-09 22:42:52 --> Loader Class Initialized
DEBUG - 2011-12-09 22:42:52 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 22:42:52 --> Controller Class Initialized
DEBUG - 2011-12-09 22:42:52 --> File loaded: application/views/welcome_view.php
DEBUG - 2011-12-09 22:43:09 --> Config Class Initialized
DEBUG - 2011-12-09 22:43:09 --> Hooks Class Initialized
DEBUG - 2011-12-09 22:43:09 --> Utf8 Class Initialized
DEBUG - 2011-12-09 22:43:09 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 22:43:09 --> URI Class Initialized
DEBUG - 2011-12-09 22:43:09 --> Router Class Initialized
DEBUG - 2011-12-09 22:43:09 --> No URI present. Default controller set.
DEBUG - 2011-12-09 22:43:09 --> Output Class Initialized
DEBUG - 2011-12-09 22:43:09 --> Security Class Initialized
DEBUG - 2011-12-09 22:43:09 --> Input Class Initialized
DEBUG - 2011-12-09 22:43:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 22:43:09 --> Language Class Initialized
DEBUG - 2011-12-09 22:43:09 --> Loader Class Initialized
DEBUG - 2011-12-09 22:43:09 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 22:43:09 --> Controller Class Initialized
DEBUG - 2011-12-09 22:43:09 --> File loaded: application/views/welcome_view.php
DEBUG - 2011-12-09 22:44:34 --> Config Class Initialized
DEBUG - 2011-12-09 22:44:34 --> Hooks Class Initialized
DEBUG - 2011-12-09 22:44:34 --> Utf8 Class Initialized
DEBUG - 2011-12-09 22:44:34 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 22:44:34 --> URI Class Initialized
DEBUG - 2011-12-09 22:44:34 --> Router Class Initialized
DEBUG - 2011-12-09 22:44:34 --> No URI present. Default controller set.
DEBUG - 2011-12-09 22:44:34 --> Output Class Initialized
DEBUG - 2011-12-09 22:44:34 --> Security Class Initialized
DEBUG - 2011-12-09 22:44:34 --> Input Class Initialized
DEBUG - 2011-12-09 22:44:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 22:44:34 --> Language Class Initialized
DEBUG - 2011-12-09 22:44:34 --> Loader Class Initialized
DEBUG - 2011-12-09 22:44:34 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 22:44:34 --> Controller Class Initialized
DEBUG - 2011-12-09 22:44:34 --> File loaded: application/views/welcome_view.php
DEBUG - 2011-12-09 22:44:35 --> Config Class Initialized
DEBUG - 2011-12-09 22:44:35 --> Hooks Class Initialized
DEBUG - 2011-12-09 22:44:35 --> Utf8 Class Initialized
DEBUG - 2011-12-09 22:44:35 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 22:44:35 --> URI Class Initialized
DEBUG - 2011-12-09 22:44:35 --> Router Class Initialized
DEBUG - 2011-12-09 22:44:35 --> No URI present. Default controller set.
DEBUG - 2011-12-09 22:44:35 --> Output Class Initialized
DEBUG - 2011-12-09 22:44:35 --> Security Class Initialized
DEBUG - 2011-12-09 22:44:35 --> Input Class Initialized
DEBUG - 2011-12-09 22:44:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 22:44:35 --> Language Class Initialized
DEBUG - 2011-12-09 22:44:35 --> Loader Class Initialized
DEBUG - 2011-12-09 22:44:35 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 22:44:35 --> Controller Class Initialized
DEBUG - 2011-12-09 22:44:35 --> File loaded: application/views/welcome_view.php
DEBUG - 2011-12-09 22:45:31 --> Config Class Initialized
DEBUG - 2011-12-09 22:45:31 --> Hooks Class Initialized
DEBUG - 2011-12-09 22:45:31 --> Utf8 Class Initialized
DEBUG - 2011-12-09 22:45:31 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 22:45:31 --> URI Class Initialized
DEBUG - 2011-12-09 22:45:31 --> Router Class Initialized
DEBUG - 2011-12-09 22:45:31 --> No URI present. Default controller set.
DEBUG - 2011-12-09 22:45:31 --> Output Class Initialized
DEBUG - 2011-12-09 22:45:31 --> Security Class Initialized
DEBUG - 2011-12-09 22:45:31 --> Input Class Initialized
DEBUG - 2011-12-09 22:45:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 22:45:31 --> Language Class Initialized
DEBUG - 2011-12-09 22:45:31 --> Loader Class Initialized
DEBUG - 2011-12-09 22:45:31 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 22:45:31 --> Controller Class Initialized
DEBUG - 2011-12-09 22:45:31 --> File loaded: application/views/welcome_view.php
DEBUG - 2011-12-09 22:47:06 --> Config Class Initialized
DEBUG - 2011-12-09 22:47:06 --> Hooks Class Initialized
DEBUG - 2011-12-09 22:47:06 --> Utf8 Class Initialized
DEBUG - 2011-12-09 22:47:06 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 22:47:06 --> URI Class Initialized
DEBUG - 2011-12-09 22:47:06 --> Router Class Initialized
DEBUG - 2011-12-09 22:47:06 --> No URI present. Default controller set.
DEBUG - 2011-12-09 22:47:06 --> Output Class Initialized
DEBUG - 2011-12-09 22:47:06 --> Security Class Initialized
DEBUG - 2011-12-09 22:47:06 --> Input Class Initialized
DEBUG - 2011-12-09 22:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 22:47:06 --> Language Class Initialized
DEBUG - 2011-12-09 22:47:06 --> Loader Class Initialized
DEBUG - 2011-12-09 22:47:06 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
INFO  - 2011-12-09 22:47:06 --> Injected: COPYRIGHT
DEBUG - 2011-12-09 22:47:06 --> Controller Class Initialized
DEBUG - 2011-12-09 22:47:06 --> File loaded: application/views/welcome_view.php
INFO  - 2011-12-09 22:47:06 --> Injected: CONTENT_VIEW
INFO  - 2011-12-09 22:47:06 --> Injected: _TPL_TITLE
INFO  - 2011-12-09 22:47:06 --> Injected: _TPL_HEAD
INFO  - 2011-12-09 22:47:06 --> Injected: _TPL_SCRIPTS
DEBUG - 2011-12-09 22:48:25 --> Config Class Initialized
DEBUG - 2011-12-09 22:48:25 --> Hooks Class Initialized
DEBUG - 2011-12-09 22:48:25 --> Utf8 Class Initialized
DEBUG - 2011-12-09 22:48:25 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 22:48:25 --> URI Class Initialized
DEBUG - 2011-12-09 22:48:25 --> Router Class Initialized
DEBUG - 2011-12-09 22:48:25 --> No URI present. Default controller set.
DEBUG - 2011-12-09 22:48:25 --> Output Class Initialized
DEBUG - 2011-12-09 22:48:25 --> Security Class Initialized
DEBUG - 2011-12-09 22:48:25 --> Input Class Initialized
DEBUG - 2011-12-09 22:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 22:48:25 --> Language Class Initialized
DEBUG - 2011-12-09 22:48:25 --> Loader Class Initialized
DEBUG - 2011-12-09 22:48:25 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 22:48:25 --> Controller Class Initialized
DEBUG - 2011-12-09 22:48:25 --> File loaded: application/views/welcome_view.php
INFO  - 2011-12-09 22:48:25 --> Replaced Marker: COPYRIGHT
INFO  - 2011-12-09 22:48:25 --> Replaced Marker: CONTENT_VIEW
INFO  - 2011-12-09 22:48:25 --> Replaced Marker: _TPL_TITLE
INFO  - 2011-12-09 22:48:25 --> Replaced Marker: _TPL_HEAD
INFO  - 2011-12-09 22:48:25 --> Replaced Marker: _TPL_SCRIPTS
DEBUG - 2011-12-09 22:59:52 --> Config Class Initialized
DEBUG - 2011-12-09 22:59:52 --> Hooks Class Initialized
DEBUG - 2011-12-09 22:59:52 --> Utf8 Class Initialized
DEBUG - 2011-12-09 22:59:52 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 22:59:52 --> URI Class Initialized
DEBUG - 2011-12-09 22:59:52 --> Router Class Initialized
DEBUG - 2011-12-09 22:59:52 --> No URI present. Default controller set.
DEBUG - 2011-12-09 22:59:52 --> Output Class Initialized
DEBUG - 2011-12-09 22:59:52 --> Security Class Initialized
DEBUG - 2011-12-09 22:59:52 --> Input Class Initialized
DEBUG - 2011-12-09 22:59:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 22:59:52 --> Language Class Initialized
DEBUG - 2011-12-09 22:59:52 --> Loader Class Initialized
DEBUG - 2011-12-09 22:59:52 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 22:59:52 --> Controller Class Initialized
DEBUG - 2011-12-09 22:59:52 --> File loaded: application/views/welcome_view.php
INFO  - 2011-12-09 22:59:52 --> Replaced Marker: COPYRIGHT
INFO  - 2011-12-09 22:59:52 --> Replaced Marker: CONTENT_VIEW
INFO  - 2011-12-09 22:59:52 --> Replaced Marker: _TPL_TITLE
INFO  - 2011-12-09 22:59:52 --> Replaced Marker: _TPL_HEAD
INFO  - 2011-12-09 22:59:52 --> Replaced Marker: _TPL_SCRIPTS
DEBUG - 2011-12-09 23:00:53 --> Config Class Initialized
DEBUG - 2011-12-09 23:00:53 --> Hooks Class Initialized
DEBUG - 2011-12-09 23:00:53 --> Utf8 Class Initialized
DEBUG - 2011-12-09 23:00:53 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 23:00:53 --> URI Class Initialized
DEBUG - 2011-12-09 23:00:53 --> Router Class Initialized
DEBUG - 2011-12-09 23:00:53 --> No URI present. Default controller set.
DEBUG - 2011-12-09 23:00:53 --> Output Class Initialized
DEBUG - 2011-12-09 23:00:53 --> Security Class Initialized
DEBUG - 2011-12-09 23:00:53 --> Input Class Initialized
DEBUG - 2011-12-09 23:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 23:00:53 --> Language Class Initialized
DEBUG - 2011-12-09 23:00:53 --> Loader Class Initialized
DEBUG - 2011-12-09 23:00:53 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 23:00:53 --> Controller Class Initialized
DEBUG - 2011-12-09 23:00:53 --> File loaded: application/views/welcome_view.php
INFO  - 2011-12-09 23:00:53 --> Replaced Marker: COPYRIGHT
INFO  - 2011-12-09 23:00:53 --> Replaced Marker: CONTENT_VIEW
INFO  - 2011-12-09 23:00:53 --> Replaced Marker: _TPL_TITLE
INFO  - 2011-12-09 23:00:53 --> Replaced Marker: _TPL_HEAD
INFO  - 2011-12-09 23:00:53 --> Replaced Marker: _TPL_SCRIPTS
DEBUG - 2011-12-09 23:02:03 --> Config Class Initialized
DEBUG - 2011-12-09 23:02:03 --> Hooks Class Initialized
DEBUG - 2011-12-09 23:02:03 --> Utf8 Class Initialized
DEBUG - 2011-12-09 23:02:03 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 23:02:03 --> URI Class Initialized
DEBUG - 2011-12-09 23:02:03 --> Router Class Initialized
DEBUG - 2011-12-09 23:02:03 --> Output Class Initialized
DEBUG - 2011-12-09 23:02:03 --> Security Class Initialized
DEBUG - 2011-12-09 23:02:03 --> Input Class Initialized
DEBUG - 2011-12-09 23:02:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 23:02:03 --> Language Class Initialized
DEBUG - 2011-12-09 23:02:03 --> Loader Class Initialized
DEBUG - 2011-12-09 23:02:03 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 23:02:03 --> Controller Class Initialized
DEBUG - 2011-12-09 23:02:19 --> Config Class Initialized
DEBUG - 2011-12-09 23:02:19 --> Hooks Class Initialized
DEBUG - 2011-12-09 23:02:19 --> Utf8 Class Initialized
DEBUG - 2011-12-09 23:02:19 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 23:02:19 --> URI Class Initialized
DEBUG - 2011-12-09 23:02:19 --> Router Class Initialized
DEBUG - 2011-12-09 23:02:19 --> No URI present. Default controller set.
DEBUG - 2011-12-09 23:02:19 --> Output Class Initialized
DEBUG - 2011-12-09 23:02:19 --> Security Class Initialized
DEBUG - 2011-12-09 23:02:19 --> Input Class Initialized
DEBUG - 2011-12-09 23:02:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 23:02:19 --> Language Class Initialized
DEBUG - 2011-12-09 23:02:19 --> Loader Class Initialized
DEBUG - 2011-12-09 23:02:19 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 23:02:19 --> Controller Class Initialized
DEBUG - 2011-12-09 23:02:19 --> File loaded: application/views/welcome_view.php
DEBUG - 2011-12-09 23:02:34 --> Config Class Initialized
DEBUG - 2011-12-09 23:02:34 --> Hooks Class Initialized
DEBUG - 2011-12-09 23:02:34 --> Utf8 Class Initialized
DEBUG - 2011-12-09 23:02:34 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 23:02:34 --> URI Class Initialized
DEBUG - 2011-12-09 23:02:34 --> Router Class Initialized
DEBUG - 2011-12-09 23:02:34 --> No URI present. Default controller set.
DEBUG - 2011-12-09 23:02:34 --> Output Class Initialized
DEBUG - 2011-12-09 23:02:34 --> Security Class Initialized
DEBUG - 2011-12-09 23:02:34 --> Input Class Initialized
DEBUG - 2011-12-09 23:02:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 23:02:34 --> Language Class Initialized
DEBUG - 2011-12-09 23:02:34 --> Loader Class Initialized
DEBUG - 2011-12-09 23:02:34 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 23:02:34 --> Controller Class Initialized
DEBUG - 2011-12-09 23:02:34 --> File loaded: application/views/welcome_view.php
DEBUG - 2011-12-09 23:02:34 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/statics/_kitchensink.php
INFO  - 2011-12-09 23:02:34 --> Replaced Marker: COPYRIGHT
INFO  - 2011-12-09 23:02:34 --> Replaced Marker: CONTENT_VIEW
INFO  - 2011-12-09 23:02:34 --> Replaced Marker: CONTENT
INFO  - 2011-12-09 23:02:34 --> Replaced Marker: _TPL_TITLE
INFO  - 2011-12-09 23:02:34 --> Replaced Marker: _TPL_HEAD
INFO  - 2011-12-09 23:02:34 --> Replaced Marker: _TPL_SCRIPTS
DEBUG - 2011-12-09 23:05:01 --> Config Class Initialized
DEBUG - 2011-12-09 23:05:01 --> Hooks Class Initialized
DEBUG - 2011-12-09 23:05:01 --> Utf8 Class Initialized
DEBUG - 2011-12-09 23:05:01 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 23:05:01 --> URI Class Initialized
DEBUG - 2011-12-09 23:05:01 --> Router Class Initialized
DEBUG - 2011-12-09 23:05:01 --> No URI present. Default controller set.
DEBUG - 2011-12-09 23:05:01 --> Output Class Initialized
DEBUG - 2011-12-09 23:05:01 --> Security Class Initialized
DEBUG - 2011-12-09 23:05:01 --> Input Class Initialized
DEBUG - 2011-12-09 23:05:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 23:05:01 --> Language Class Initialized
DEBUG - 2011-12-09 23:05:01 --> Loader Class Initialized
DEBUG - 2011-12-09 23:05:01 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 23:05:01 --> Controller Class Initialized
DEBUG - 2011-12-09 23:05:01 --> File loaded: application/views/welcome_view.php
INFO  - 2011-12-09 23:05:01 --> Replaced Marker: COPYRIGHT
INFO  - 2011-12-09 23:05:01 --> Replaced Marker: CONTENT_VIEW
INFO  - 2011-12-09 23:05:01 --> Replaced Marker: _TPL_TITLE
INFO  - 2011-12-09 23:05:01 --> Replaced Marker: _TPL_HEAD
INFO  - 2011-12-09 23:05:01 --> Replaced Marker: _TPL_SCRIPTS
DEBUG - 2011-12-09 23:23:27 --> Config Class Initialized
DEBUG - 2011-12-09 23:23:27 --> Hooks Class Initialized
DEBUG - 2011-12-09 23:23:27 --> Utf8 Class Initialized
DEBUG - 2011-12-09 23:23:27 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 23:23:27 --> URI Class Initialized
DEBUG - 2011-12-09 23:23:27 --> Router Class Initialized
DEBUG - 2011-12-09 23:23:27 --> No URI present. Default controller set.
DEBUG - 2011-12-09 23:23:27 --> Output Class Initialized
DEBUG - 2011-12-09 23:23:27 --> Security Class Initialized
DEBUG - 2011-12-09 23:23:27 --> Input Class Initialized
DEBUG - 2011-12-09 23:23:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 23:23:27 --> Language Class Initialized
DEBUG - 2011-12-09 23:23:27 --> Loader Class Initialized
DEBUG - 2011-12-09 23:23:27 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 23:23:27 --> Controller Class Initialized
DEBUG - 2011-12-09 23:23:27 --> File loaded: application/views/welcome_view.php
INFO  - 2011-12-09 23:23:27 --> Replaced Marker: COPYRIGHT
INFO  - 2011-12-09 23:23:27 --> Replaced Marker: CONTENT_VIEW
INFO  - 2011-12-09 23:23:27 --> Replaced Marker: _TPL_TITLE
INFO  - 2011-12-09 23:23:27 --> Replaced Marker: _TPL_HEAD
INFO  - 2011-12-09 23:23:27 --> Replaced Marker: _TPL_SCRIPTS
DEBUG - 2011-12-09 23:23:43 --> Config Class Initialized
DEBUG - 2011-12-09 23:23:43 --> Hooks Class Initialized
DEBUG - 2011-12-09 23:23:43 --> Utf8 Class Initialized
DEBUG - 2011-12-09 23:23:43 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 23:23:43 --> URI Class Initialized
DEBUG - 2011-12-09 23:23:43 --> Router Class Initialized
DEBUG - 2011-12-09 23:23:43 --> No URI present. Default controller set.
DEBUG - 2011-12-09 23:23:43 --> Output Class Initialized
DEBUG - 2011-12-09 23:23:43 --> Security Class Initialized
DEBUG - 2011-12-09 23:23:43 --> Input Class Initialized
DEBUG - 2011-12-09 23:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 23:23:43 --> Language Class Initialized
DEBUG - 2011-12-09 23:23:43 --> Loader Class Initialized
DEBUG - 2011-12-09 23:23:43 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 23:23:43 --> Controller Class Initialized
DEBUG - 2011-12-09 23:23:43 --> File loaded: application/views/welcome_view.php
INFO  - 2011-12-09 23:23:43 --> Replaced Marker: COPYRIGHT
INFO  - 2011-12-09 23:23:43 --> Replaced Marker: CONTENT_VIEW
INFO  - 2011-12-09 23:23:43 --> Replaced Marker: _TPL_TITLE
INFO  - 2011-12-09 23:23:43 --> Replaced Marker: _TPL_HEAD
INFO  - 2011-12-09 23:23:43 --> Replaced Marker: _TPL_SCRIPTS
DEBUG - 2011-12-09 23:23:57 --> Config Class Initialized
DEBUG - 2011-12-09 23:23:57 --> Hooks Class Initialized
DEBUG - 2011-12-09 23:23:57 --> Utf8 Class Initialized
DEBUG - 2011-12-09 23:23:57 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 23:23:57 --> URI Class Initialized
DEBUG - 2011-12-09 23:23:57 --> Router Class Initialized
DEBUG - 2011-12-09 23:23:57 --> No URI present. Default controller set.
DEBUG - 2011-12-09 23:23:57 --> Output Class Initialized
DEBUG - 2011-12-09 23:23:57 --> Security Class Initialized
DEBUG - 2011-12-09 23:23:57 --> Input Class Initialized
DEBUG - 2011-12-09 23:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 23:23:57 --> Language Class Initialized
DEBUG - 2011-12-09 23:23:57 --> Loader Class Initialized
DEBUG - 2011-12-09 23:23:57 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 23:23:57 --> Controller Class Initialized
DEBUG - 2011-12-09 23:23:57 --> File loaded: application/views/welcome_view.php
INFO  - 2011-12-09 23:23:57 --> Replaced Marker: COPYRIGHT
INFO  - 2011-12-09 23:23:57 --> Replaced Marker: CONTENT_VIEW
INFO  - 2011-12-09 23:23:57 --> Replaced Marker: _TPL_TITLE
INFO  - 2011-12-09 23:23:57 --> Replaced Marker: _TPL_HEAD
INFO  - 2011-12-09 23:23:57 --> Replaced Marker: _TPL_SCRIPTS
DEBUG - 2011-12-09 23:26:12 --> Config Class Initialized
DEBUG - 2011-12-09 23:26:12 --> Hooks Class Initialized
DEBUG - 2011-12-09 23:26:12 --> Utf8 Class Initialized
DEBUG - 2011-12-09 23:26:12 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 23:26:12 --> URI Class Initialized
DEBUG - 2011-12-09 23:26:12 --> Router Class Initialized
DEBUG - 2011-12-09 23:26:12 --> No URI present. Default controller set.
DEBUG - 2011-12-09 23:26:12 --> Output Class Initialized
DEBUG - 2011-12-09 23:26:12 --> Security Class Initialized
DEBUG - 2011-12-09 23:26:12 --> Input Class Initialized
DEBUG - 2011-12-09 23:26:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 23:26:12 --> Language Class Initialized
DEBUG - 2011-12-09 23:26:12 --> Loader Class Initialized
DEBUG - 2011-12-09 23:26:12 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 23:26:12 --> Controller Class Initialized
DEBUG - 2011-12-09 23:26:12 --> File loaded: application/views/welcome_view.php
ERROR - 2011-12-09 23:26:12 --> Severity: Notice  --> Undefined property: Document::$profiler /Users/_druu/Sites/ci-document/application/libraries/Document.php 529
DEBUG - 2011-12-09 23:32:55 --> Config Class Initialized
DEBUG - 2011-12-09 23:32:55 --> Hooks Class Initialized
DEBUG - 2011-12-09 23:32:55 --> Utf8 Class Initialized
DEBUG - 2011-12-09 23:32:55 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 23:32:55 --> URI Class Initialized
DEBUG - 2011-12-09 23:32:55 --> Router Class Initialized
DEBUG - 2011-12-09 23:32:55 --> No URI present. Default controller set.
DEBUG - 2011-12-09 23:32:55 --> Output Class Initialized
DEBUG - 2011-12-09 23:32:55 --> Security Class Initialized
DEBUG - 2011-12-09 23:32:55 --> Input Class Initialized
DEBUG - 2011-12-09 23:32:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 23:32:55 --> Language Class Initialized
DEBUG - 2011-12-09 23:32:55 --> Loader Class Initialized
DEBUG - 2011-12-09 23:32:55 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 23:32:55 --> Controller Class Initialized
DEBUG - 2011-12-09 23:32:55 --> File loaded: application/views/welcome_view.php
INFO  - 2011-12-09 23:32:55 --> Replaced Marker: COPYRIGHT
INFO  - 2011-12-09 23:32:55 --> Replaced Marker: CONTENT_VIEW
INFO  - 2011-12-09 23:32:55 --> Replaced Marker: _TPL_TITLE
INFO  - 2011-12-09 23:32:55 --> Replaced Marker: _TPL_HEAD
INFO  - 2011-12-09 23:32:55 --> Replaced Marker: _TPL_SCRIPTS
DEBUG - 2011-12-09 23:33:25 --> Config Class Initialized
DEBUG - 2011-12-09 23:33:25 --> Hooks Class Initialized
DEBUG - 2011-12-09 23:33:25 --> Utf8 Class Initialized
DEBUG - 2011-12-09 23:33:25 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 23:33:25 --> URI Class Initialized
DEBUG - 2011-12-09 23:33:25 --> Router Class Initialized
DEBUG - 2011-12-09 23:33:25 --> No URI present. Default controller set.
DEBUG - 2011-12-09 23:33:25 --> Output Class Initialized
DEBUG - 2011-12-09 23:33:25 --> Security Class Initialized
DEBUG - 2011-12-09 23:33:25 --> Input Class Initialized
DEBUG - 2011-12-09 23:33:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 23:33:25 --> Language Class Initialized
DEBUG - 2011-12-09 23:33:25 --> Loader Class Initialized
DEBUG - 2011-12-09 23:33:25 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 23:33:25 --> Controller Class Initialized
DEBUG - 2011-12-09 23:33:37 --> Config Class Initialized
DEBUG - 2011-12-09 23:33:37 --> Hooks Class Initialized
DEBUG - 2011-12-09 23:33:37 --> Utf8 Class Initialized
DEBUG - 2011-12-09 23:33:37 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 23:33:37 --> URI Class Initialized
DEBUG - 2011-12-09 23:33:37 --> Router Class Initialized
DEBUG - 2011-12-09 23:33:37 --> No URI present. Default controller set.
DEBUG - 2011-12-09 23:33:37 --> Output Class Initialized
DEBUG - 2011-12-09 23:33:37 --> Security Class Initialized
DEBUG - 2011-12-09 23:33:37 --> Input Class Initialized
DEBUG - 2011-12-09 23:33:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 23:33:37 --> Language Class Initialized
DEBUG - 2011-12-09 23:33:37 --> Loader Class Initialized
DEBUG - 2011-12-09 23:33:37 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 23:33:37 --> Controller Class Initialized
DEBUG - 2011-12-09 23:33:37 --> File loaded: application/views/welcome_view.php
ERROR - 2011-12-09 23:33:37 --> Severity: Notice  --> Undefined property: Document::$load /Users/_druu/Sites/ci-document/application/libraries/Document.php 539
DEBUG - 2011-12-09 23:38:40 --> Config Class Initialized
DEBUG - 2011-12-09 23:38:40 --> Hooks Class Initialized
DEBUG - 2011-12-09 23:38:40 --> Utf8 Class Initialized
DEBUG - 2011-12-09 23:38:40 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 23:38:40 --> URI Class Initialized
DEBUG - 2011-12-09 23:38:40 --> Router Class Initialized
DEBUG - 2011-12-09 23:38:40 --> No URI present. Default controller set.
DEBUG - 2011-12-09 23:38:40 --> Output Class Initialized
DEBUG - 2011-12-09 23:38:40 --> Security Class Initialized
DEBUG - 2011-12-09 23:38:40 --> Input Class Initialized
DEBUG - 2011-12-09 23:38:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 23:38:40 --> Language Class Initialized
DEBUG - 2011-12-09 23:38:40 --> Loader Class Initialized
DEBUG - 2011-12-09 23:38:40 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 23:38:40 --> Controller Class Initialized
DEBUG - 2011-12-09 23:38:40 --> File loaded: application/views/welcome_view.php
INFO  - 2011-12-09 23:38:40 --> Replaced Marker: COPYRIGHT
INFO  - 2011-12-09 23:38:40 --> Replaced Marker: CONTENT_VIEW
INFO  - 2011-12-09 23:38:40 --> Replaced Marker: _TPL_TITLE
INFO  - 2011-12-09 23:38:40 --> Replaced Marker: _TPL_HEAD
INFO  - 2011-12-09 23:38:40 --> Replaced Marker: _TPL_SCRIPTS
DEBUG - 2011-12-09 23:39:45 --> Config Class Initialized
DEBUG - 2011-12-09 23:39:45 --> Hooks Class Initialized
DEBUG - 2011-12-09 23:39:45 --> Utf8 Class Initialized
DEBUG - 2011-12-09 23:39:45 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 23:39:45 --> URI Class Initialized
DEBUG - 2011-12-09 23:39:45 --> Router Class Initialized
DEBUG - 2011-12-09 23:39:45 --> No URI present. Default controller set.
DEBUG - 2011-12-09 23:39:45 --> Output Class Initialized
DEBUG - 2011-12-09 23:39:45 --> Security Class Initialized
DEBUG - 2011-12-09 23:39:45 --> Input Class Initialized
DEBUG - 2011-12-09 23:39:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 23:39:45 --> Language Class Initialized
DEBUG - 2011-12-09 23:39:45 --> Loader Class Initialized
DEBUG - 2011-12-09 23:39:45 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 23:39:45 --> Controller Class Initialized
DEBUG - 2011-12-09 23:39:45 --> File loaded: application/views/welcome_view.php
INFO  - 2011-12-09 23:39:45 --> Replaced Marker: COPYRIGHT
INFO  - 2011-12-09 23:39:45 --> Replaced Marker: CONTENT_VIEW
INFO  - 2011-12-09 23:39:45 --> Replaced Marker: _TPL_TITLE
INFO  - 2011-12-09 23:39:45 --> Replaced Marker: _TPL_HEAD
INFO  - 2011-12-09 23:39:45 --> Replaced Marker: _TPL_SCRIPTS
DEBUG - 2011-12-09 23:40:00 --> Config Class Initialized
DEBUG - 2011-12-09 23:40:00 --> Hooks Class Initialized
DEBUG - 2011-12-09 23:40:00 --> Utf8 Class Initialized
DEBUG - 2011-12-09 23:40:00 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 23:40:00 --> URI Class Initialized
DEBUG - 2011-12-09 23:40:00 --> Router Class Initialized
DEBUG - 2011-12-09 23:40:00 --> No URI present. Default controller set.
DEBUG - 2011-12-09 23:40:00 --> Output Class Initialized
DEBUG - 2011-12-09 23:40:00 --> Security Class Initialized
DEBUG - 2011-12-09 23:40:00 --> Input Class Initialized
DEBUG - 2011-12-09 23:40:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 23:40:00 --> Language Class Initialized
DEBUG - 2011-12-09 23:40:00 --> Loader Class Initialized
DEBUG - 2011-12-09 23:40:00 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 23:40:00 --> Controller Class Initialized
DEBUG - 2011-12-09 23:40:00 --> File loaded: application/views/welcome_view.php
INFO  - 2011-12-09 23:40:00 --> Replaced Marker: COPYRIGHT
INFO  - 2011-12-09 23:40:00 --> Replaced Marker: CONTENT_VIEW
INFO  - 2011-12-09 23:40:00 --> Replaced Marker: _TPL_TITLE
INFO  - 2011-12-09 23:40:00 --> Replaced Marker: _TPL_HEAD
INFO  - 2011-12-09 23:40:00 --> Replaced Marker: _TPL_SCRIPTS
DEBUG - 2011-12-09 23:44:58 --> Config Class Initialized
DEBUG - 2011-12-09 23:44:58 --> Hooks Class Initialized
DEBUG - 2011-12-09 23:44:58 --> Utf8 Class Initialized
DEBUG - 2011-12-09 23:44:58 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 23:44:58 --> URI Class Initialized
DEBUG - 2011-12-09 23:44:58 --> Router Class Initialized
DEBUG - 2011-12-09 23:44:58 --> No URI present. Default controller set.
DEBUG - 2011-12-09 23:44:58 --> Output Class Initialized
DEBUG - 2011-12-09 23:44:58 --> Security Class Initialized
DEBUG - 2011-12-09 23:44:58 --> Input Class Initialized
DEBUG - 2011-12-09 23:44:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 23:44:58 --> Language Class Initialized
DEBUG - 2011-12-09 23:44:58 --> Loader Class Initialized
DEBUG - 2011-12-09 23:44:58 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 23:44:58 --> Controller Class Initialized
DEBUG - 2011-12-09 23:44:58 --> File loaded: application/views/welcome_view.php
INFO  - 2011-12-09 23:44:58 --> Replaced Marker: COPYRIGHT
INFO  - 2011-12-09 23:44:58 --> Replaced Marker: CONTENT_VIEW
INFO  - 2011-12-09 23:44:58 --> Replaced Marker: _TPL_TITLE
INFO  - 2011-12-09 23:44:58 --> Replaced Marker: _TPL_HEAD
INFO  - 2011-12-09 23:44:58 --> Replaced Marker: _TPL_SCRIPTS
ERROR - 2011-12-09 23:44:58 --> Severity: Notice  --> Undefined property: Document::$parse_exec_vars /Users/_druu/Sites/ci-document/application/libraries/Document.php 553
DEBUG - 2011-12-09 23:46:17 --> Config Class Initialized
DEBUG - 2011-12-09 23:46:17 --> Hooks Class Initialized
DEBUG - 2011-12-09 23:46:17 --> Utf8 Class Initialized
DEBUG - 2011-12-09 23:46:17 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 23:46:17 --> URI Class Initialized
DEBUG - 2011-12-09 23:46:17 --> Router Class Initialized
DEBUG - 2011-12-09 23:46:17 --> No URI present. Default controller set.
DEBUG - 2011-12-09 23:46:17 --> Output Class Initialized
DEBUG - 2011-12-09 23:46:17 --> Security Class Initialized
DEBUG - 2011-12-09 23:46:17 --> Input Class Initialized
DEBUG - 2011-12-09 23:46:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 23:46:17 --> Language Class Initialized
DEBUG - 2011-12-09 23:46:17 --> Loader Class Initialized
DEBUG - 2011-12-09 23:46:17 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 23:46:17 --> Controller Class Initialized
DEBUG - 2011-12-09 23:46:17 --> File loaded: application/views/welcome_view.php
INFO  - 2011-12-09 23:46:17 --> Replaced Marker: COPYRIGHT
INFO  - 2011-12-09 23:46:17 --> Replaced Marker: CONTENT_VIEW
INFO  - 2011-12-09 23:46:17 --> Replaced Marker: _TPL_TITLE
INFO  - 2011-12-09 23:46:17 --> Replaced Marker: _TPL_HEAD
INFO  - 2011-12-09 23:46:17 --> Replaced Marker: _TPL_SCRIPTS
ERROR - 2011-12-09 23:46:17 --> Severity: Notice  --> Undefined property: Document::$parse_exec_vars /Users/_druu/Sites/ci-document/application/libraries/Document.php 553
DEBUG - 2011-12-09 23:46:51 --> Config Class Initialized
DEBUG - 2011-12-09 23:46:51 --> Hooks Class Initialized
DEBUG - 2011-12-09 23:46:51 --> Utf8 Class Initialized
DEBUG - 2011-12-09 23:46:51 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 23:46:51 --> URI Class Initialized
DEBUG - 2011-12-09 23:46:51 --> Router Class Initialized
DEBUG - 2011-12-09 23:46:51 --> No URI present. Default controller set.
DEBUG - 2011-12-09 23:46:51 --> Output Class Initialized
DEBUG - 2011-12-09 23:46:51 --> Security Class Initialized
DEBUG - 2011-12-09 23:46:51 --> Input Class Initialized
DEBUG - 2011-12-09 23:46:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 23:46:51 --> Language Class Initialized
DEBUG - 2011-12-09 23:46:51 --> Loader Class Initialized
DEBUG - 2011-12-09 23:46:51 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 23:46:51 --> Controller Class Initialized
DEBUG - 2011-12-09 23:46:51 --> File loaded: application/views/welcome_view.php
INFO  - 2011-12-09 23:46:51 --> Replaced Marker: COPYRIGHT
INFO  - 2011-12-09 23:46:51 --> Replaced Marker: CONTENT_VIEW
INFO  - 2011-12-09 23:46:51 --> Replaced Marker: _TPL_TITLE
INFO  - 2011-12-09 23:46:51 --> Replaced Marker: _TPL_HEAD
INFO  - 2011-12-09 23:46:51 --> Replaced Marker: _TPL_SCRIPTS
ERROR - 2011-12-09 23:46:51 --> Severity: Notice  --> Undefined property: Document::$parse_exec_vars /Users/_druu/Sites/ci-document/application/libraries/Document.php 553
DEBUG - 2011-12-09 23:47:11 --> Config Class Initialized
DEBUG - 2011-12-09 23:47:11 --> Hooks Class Initialized
DEBUG - 2011-12-09 23:47:11 --> Utf8 Class Initialized
DEBUG - 2011-12-09 23:47:11 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 23:47:11 --> URI Class Initialized
DEBUG - 2011-12-09 23:47:11 --> Router Class Initialized
DEBUG - 2011-12-09 23:47:11 --> No URI present. Default controller set.
DEBUG - 2011-12-09 23:47:11 --> Output Class Initialized
DEBUG - 2011-12-09 23:47:11 --> Security Class Initialized
DEBUG - 2011-12-09 23:47:11 --> Input Class Initialized
DEBUG - 2011-12-09 23:47:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 23:47:11 --> Language Class Initialized
DEBUG - 2011-12-09 23:47:11 --> Loader Class Initialized
DEBUG - 2011-12-09 23:47:11 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 23:47:11 --> Controller Class Initialized
DEBUG - 2011-12-09 23:47:11 --> File loaded: application/views/welcome_view.php
INFO  - 2011-12-09 23:47:11 --> Replaced Marker: COPYRIGHT
INFO  - 2011-12-09 23:47:11 --> Replaced Marker: CONTENT_VIEW
INFO  - 2011-12-09 23:47:11 --> Replaced Marker: _TPL_TITLE
INFO  - 2011-12-09 23:47:11 --> Replaced Marker: _TPL_HEAD
INFO  - 2011-12-09 23:47:11 --> Replaced Marker: _TPL_SCRIPTS
DEBUG - 2011-12-09 23:52:14 --> Config Class Initialized
DEBUG - 2011-12-09 23:52:14 --> Hooks Class Initialized
DEBUG - 2011-12-09 23:52:14 --> Utf8 Class Initialized
DEBUG - 2011-12-09 23:52:14 --> UTF-8 Support Enabled
DEBUG - 2011-12-09 23:52:14 --> URI Class Initialized
DEBUG - 2011-12-09 23:52:14 --> Router Class Initialized
DEBUG - 2011-12-09 23:52:14 --> No URI present. Default controller set.
DEBUG - 2011-12-09 23:52:14 --> Output Class Initialized
DEBUG - 2011-12-09 23:52:14 --> Security Class Initialized
DEBUG - 2011-12-09 23:52:14 --> Input Class Initialized
DEBUG - 2011-12-09 23:52:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-12-09 23:52:14 --> Language Class Initialized
DEBUG - 2011-12-09 23:52:14 --> Loader Class Initialized
DEBUG - 2011-12-09 23:52:14 --> File loaded: /Users/_druu/Sites/ci-document/templates/default/base/_index.php
DEBUG - 2011-12-09 23:52:14 --> Controller Class Initialized
DEBUG - 2011-12-09 23:52:14 --> File loaded: application/views/welcome_view.php
INFO  - 2011-12-09 23:52:14 --> Replaced Marker: COPYRIGHT
INFO  - 2011-12-09 23:52:14 --> Replaced Marker: CONTENT_VIEW
INFO  - 2011-12-09 23:52:14 --> Replaced Marker: _TPL_TITLE
INFO  - 2011-12-09 23:52:14 --> Replaced Marker: _TPL_HEAD
INFO  - 2011-12-09 23:52:14 --> Replaced Marker: _TPL_SCRIPTS
