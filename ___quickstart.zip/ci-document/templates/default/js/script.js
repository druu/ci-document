if (typeof console !== 'undefined') {
	console.log('F/YEAH');
}