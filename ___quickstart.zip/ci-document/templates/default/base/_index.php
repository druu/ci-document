<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>#@#_TPL_TITLE#@#</title>

  #@#_TPL_HEAD#@#
</head>
<body>

<div id="container">
  #@#CONTENT_VIEW#@#
  <div style="margin:15px">
  #@#CONTENT#@#
  </div>
</div>
#@#FOOTNOTE#@#

</body>
</html>